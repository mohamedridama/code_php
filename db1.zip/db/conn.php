<?php

$cox=mysqli_connect("localhost", "root","","smi6");
if(mysqli_connect_errno()){
	echo "erreur de connection";


}
else{
	//echo "connection avec succès";
}

?>
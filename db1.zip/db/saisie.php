<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>saisie des données</title>
</head>
<body>
<form method="post" >
CNE:<input type="text" name="cne"><br>
NOM:<input type="text" name="nm"><br>	
PRENOM:<input type="text" name="pn"><br>	
ADRESSE:<input type="text" name="adr"><br>	
DATE DE NAISSANCE:<input type="DATE" name="dt"><br>
NOMBRE DE MODULES VALIDES: <input type="number" name="md"><br>	
<input type="submit" name="valider" value="valider">
</form>

	<?php
		include 'conn.php';
		if(isset($_POST['valider'])){

		
		$cne=$_POST['cne'];
		$nm=$_POST['nm'];
		$pn=$_POST['pn'];
		$adr=$_POST['adr'];
		$dt=$_POST['dt'];
		$md=$_POST['md'];
		$sql="insert into etudiant(cne,nom,prenom,adresse,date_naissance,nb_mod_valide) values('$cne','$nm', '$pn','$adr','$dt',$md)";
		if($cox->query($sql)===false){
			echo "erreur d'insertion";
		}
		else{
			echo "insertion avec succès";
		}
}

	?>

</body>
</html>
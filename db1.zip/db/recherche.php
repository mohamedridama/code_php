<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>recherche</title>
</head>
<body>


<?php
include 'conn.php';

if (isset($_GET['cne'])) {
	// code...
	$c=$_GET['cne'];
	$sql="select * from etudiant where cne='$c'";
	$res=$cox->query($sql);
	if ($res===false) {
		// code...
		echo "erreur de requette";
	}
	else{
		$row=$res->fetch_row();
		//print_r($row);
		echo "<form method=post action='modif.php'>";
		echo "cne: <input type=text name=cne value=$row[0]> <br>";

		echo "nom: <input type=text name=nm value=$row[1]><br>";
		echo "Prenom:<input type=text name=pn value=$row[2]><br>";
		echo "adresse: <input type=text name=adr value=$row[3]><br>";
		echo "date de naissance: <input type=text name=dt value=$row[4]><br>";
		echo "nombre de modules: <input type=text name=nb value=$row[6]><br>";
		echo "<input type=submit name
	=modif value=modifier>";
	echo "<input type=submit name=suppr value=supprimer>";
		echo "</form>";
	}
}

?>
</body>
</html>
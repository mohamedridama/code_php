<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>affichage des données</title>
</head>
<body>
	<?php
	include "conn.php";

	$sql="select * from etudiant";
	$res=$cox->query($sql);
	if($res===false){
		echo "problème de requette";

	}
	else{
		//print_r($res);
		$res->data_seek(0);
		echo "<table border=1>";
		echo "<tr>";
		echo "<th> CNE</th>";
		echo "<th> NOM</th>";
		echo "<th> PRENOM</th>";
		echo "<th> ADRESSE</th>";
		echo "<th> DATE DE NAISSANCE</th>";
		echo "<th> NOMBRE DE MODULE</th>";
		echo "<th> actions</th>";
		Echo "</tr>";
		while($row=$res->fetch_row()){
			//print_r($row);

			echo "<tr>";
			echo "<td>$row[0]</td>";
			echo "<td>$row[1]</td>";
			echo "<td>$row[2]</td>";
			echo "<td>$row[3]</td>";
			echo "<td>$row[4]</td>";
			echo "<td>$row[5]</td>";
			echo "<td> <a href=recherche.php?cne=$row[0]>modifier</a>  </td>";
			echo "</tr>";


		}
		echo "</table>";

	}

	?>

</body>
</html>
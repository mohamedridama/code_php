<?php


include "conn.php";
if (isset($_POST['modif'])) {
	// code...
	$c=$_POST['cne'];
	$nm=$_POST['nm'];
	$pn=$_POST['pn'];
	$a=$_POST['adr'];
	$d=$_POST['dt'];
	$n=$_POST['nb'];
	$sql="update etudiant set cne='$c', nom='$nm', prenom='$pn', adresse='$a',date_naissance='$d', nb_mod_valide=$n where cne='$c'";
	if($cox->query($sql)===false){
		echo "erreur de requête";
	}
	else{
		echo "modification avec succès";
	}


}
if (isset($_POST['suppr'])) {

	// code...
	$c=$_POST['cne'];
	$sql="delete from etudiant where cne='$c'";
	if($cox->query($sql)===false){
		echo "erreur";
	}
	else{
		echo "suppression avec succès";
	}

}

?>